package com.hym.cache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 13:48
 * @Description: com.hym.api
 * @version: 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class CacheStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(CacheStarterApp.class, args);
    }
}
