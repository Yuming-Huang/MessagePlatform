package com.hym.cache.controller;

import com.msb.framework.redis.RedisClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/12 - 03 - 12 - 17:00
 * @Description: com.hym.cache.controller
 * @version: 1.0
 */
@RestController
public class TestController {

    @Autowired
    private RedisClient  redisClient;

    //写数据 Hash结构
    @PostMapping("/test/set/{key}")
    public String set(@PathVariable String key, @RequestBody Map map) {
        redisClient.hSet(key, map);
        return "success";
    }

    //读数据Hash结构
    @GetMapping("/test/get/{key}")
    public Map get(@PathVariable String key) {
        Map<String, Object> map = redisClient.hGetAll(key);
        return map;
    }
}
