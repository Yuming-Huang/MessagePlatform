package com.hym.strategy.filter.impl;

import com.hym.constant.CacheConstant;
import com.hym.constant.RabbitMQConstants;
import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import com.hym.strategy.filter.StrategyFilter;
import com.hym.strategy.util.MobileOperatorUtil;
import com.hym.util.OperatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 18:43
 * @Description: 补全校验
 * @version: 1.0
 */
@Slf4j
@Service(value = "phase")
public class PhaseStrategyFilter implements StrategyFilter {
    /**
     * 切分手机号前7位
     */
    private final int MOBILE_START = 0;
    private final int MOBILE_END = 7;
    /**
     * 校验的长度
     */
    private final int LENGTH = 2;
    /**
     * 分割区域和运营商的标识
     */
    private final String SEPARATE = ",";
    /**
     * 未知的情况
     */
    private final String UNKNOWN = "未知 未知,未知";

    @Autowired
    private BeaconCacheClient beaconCacheClient;


    @Autowired
    private MobileOperatorUtil mobileOperatorUtil;

    @Autowired
    private RabbitTemplate rabbitTemplate;


    @Override
    public void check(StandardSubmit submit) {
        log.info("【策略模块-号段补齐】   补全ing…………");
        System.out.println("已经进入号段补齐");
        //  1.根据手机号前7位，查询手机号信息
        String mobile = submit.getMobile().substring(0, 7);
        String mobileInfo = beaconCacheClient.getString(CacheConstant.PHASE + mobile);

        getMobileInfo: if (StringUtils.isEmpty(mobileInfo))  {
            //2、查询不到，需要调用三方接口，查询手机号对应信息
            mobileInfo = mobileOperatorUtil.getMobileInfoBy360(mobile);
            if(!StringUtils.isEmpty(mobileInfo)){
                //3、调用三方查到信息后，发送消息到MQ，并且同步到MySQL和Redis
                rabbitTemplate.convertAndSend(RabbitMQConstants.MOBILE_AREA_OPERATOR,submit.getMobile());
                break getMobileInfo;
            }
            mobileInfo = UNKNOWN;
        }

        //4、无论是Redis还是三方接口查询到之后，封装到StandardSubmit对象中
        String[] areaAndOperator = mobileInfo.split(SEPARATE);
        if (areaAndOperator.length == LENGTH) {
            submit.setArea(areaAndOperator[0]);
            submit.setOperatorId(OperatorUtil.getOperatorIdByOperatorName(areaAndOperator[1]));
        }
    }
}
