package com.hym.strategy.util;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 15:16
 * @Description: com.hym.strategy.util
 * @version: 1.0
 */
public class ClientBalanceUtil {
    public static Long getClientAmountLimit(Long clientId) {
        return -10000L;
    }
}
