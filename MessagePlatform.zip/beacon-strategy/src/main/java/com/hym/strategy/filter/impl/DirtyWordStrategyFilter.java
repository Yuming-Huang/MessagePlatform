package com.hym.strategy.filter.impl;

import com.hym.constant.CacheConstant;
import com.hym.constant.RabbitMQConstants;
import com.hym.constant.StrategyConstant;
import com.hym.enums.ExceptionEnums;
import com.hym.exception.StrategyException;
import com.hym.model.StandardReport;
import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import com.hym.strategy.filter.StrategyFilter;
import com.hym.strategy.util.ErrorSendMsgUtil;
import com.hym.strategy.util.HutoolDFAUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.hym.constant.CacheConstant.CLIENT_BUSINESS;
import static com.hym.constant.StrategyConstant.IS_CALLBACK;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 18:45
 * @Description: com.hym.strategy.filter.impl
 * @version: 1.0
 */
@Slf4j
@Service(value = "dirtyword")
public class DirtyWordStrategyFilter implements StrategyFilter {



    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private BeaconCacheClient cacheClient;

    @Autowired
    private ErrorSendMsgUtil errorSendMsgUtil;

    @Override
    public void check(StandardSubmit submit) {
        log.info("【策略模块-敏感词校验】   校验ing…………");
        System.out.println("已经进入敏感词校验");
        //  1.获取短信内容
        String text = submit.getText();

        //2、 调用DFA查看敏感词
        List<String> dirtyWords = HutoolDFAUtil.getDirtyWord(text);

        //4、 根据返回的set集合，判断是否包含敏感词
        if (dirtyWords != null && dirtyWords.size() > 0) {
            //5、 如果有敏感词，抛出异常 / 其他操作。。
            log.info("【策略模块-敏感词校验】   短信内容包含敏感词信息， dirtyWords = {}", dirtyWords);

            // 还需要做其他处理：（1）抛出异常 （2）发送日志信息 （3）发送状态报告消息

            // ===============  发送日志信息  ==============
            submit.setErrorMsg(ExceptionEnums.HAVE_DIRTY_WORD.getMsg() + "dirtyWords = " + dirtyWords.toString());
            errorSendMsgUtil.sendWriteLog(submit);

            // ===============  发送状态错误报告消息  ==============
            errorSendMsgUtil.sendPushReport(submit);

            // ===============  抛出异常  ==============
            throw new StrategyException(ExceptionEnums.HAVE_DIRTY_WORD);
        }


    }
}
