package com.hym.strategy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 16:52
 * @Description: com.hym.strategy
 * @version: 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class StrategyStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(StrategyStarterApp.class,args);
    }

    /**
     * @Description: RestTemplate是Spring框架提供的用于访问RESTful服务的客户端模板类。
     *
     * 它简化了与RESTful Web服务的交互过程，例如：
     *
     * 它可以方便地发送HTTP请求（如GET、POST、PUT、DELETE等）到指定的URL。
     * 处理请求和响应的序列化与反序列化，比如将Java对象转换为JSON格式发送到服务端（序列化），以及将服务端返回的JSON数据转换为Java对象（反序列化）。
     *
     * 例如，你可以使用RestTemplate来调用一个提供REST API的服务，获取数据或者提交数据到该服务。
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
