package com.hym.strategy.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 22:13
 * @Description: com.hym.strategy.util
 * @version: 1.0
 */
@Component
public class MobileOperatorUtil {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    private final String url = "https://cx.shouji.360.cn/phonearea.php?number=";

    private final String CODE = "code";
    private final String DATA = "data";
    private final String PROVINCE = "province";
    private final String CITY = "city";
    private final String SP = "sp";
    private final String SPACE = " ";
    private final String SEPARATE = ",";

    public String getMobileInfoBy360(String mobile) {

        //  1.发送请求获取信息
        String mobileInfoJson = restTemplate.getForObject(url + mobile, String.class);
        /**
         * {"code":0,"data":{"province":"\u5929\u6d25","city":"","sp":"\u79fb\u52a8"}}
         */
        //  2.解析Json
        Map map = null;
        try {
            map = objectMapper.readValue(mobileInfoJson, Map.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        Integer code = (Integer) map.get(CODE);
        if (code != 0) {
            return null ;
        }
        String province = (String) map.get(PROVINCE);
        String city = (String) map.get(CITY);
        String sp = (String) map.get(SP);
        String mobileInfo = new String(province + city+"," + sp );
        return  mobileInfo;
    }
}
