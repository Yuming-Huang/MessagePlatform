package com.hym.strategy.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.hym.constant.RabbitMQConstants.*;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 23:40
 * @Description: com.hym.strategy.config
 * @version: 1.0
 */
@Slf4j
@Configuration
public class RabbitMQConfig {
    /**
     * 接口模块发送手机号归属地&运营商到后台管理模块的队列名称
     * @return
     */
    @Bean
    public Queue queueToMobileAreaOperator() {
        return QueueBuilder.durable(MOBILE_AREA_OPERATOR).build();
    }

    @Bean
    public Queue queueToElasticsearch() {
        return QueueBuilder.durable(SMS_WRITE_LOG).build();
    }

    @Bean
    public Queue queueToNotify() {
        return QueueBuilder.durable(SMS_PUSH_REPORT).build();
    }
}
