package com.hym.strategy.filter;

import com.hym.constant.CacheConstant;
import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 策略模块校验链的执行
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 18:48
 * @Description: com.hym.strategy.filter
 * @version: 1.0
 */
@Component
@Slf4j
public class StrategyFilterContext {

    @Autowired
    private Map<String, StrategyFilter> strategyFilterMap;

    @Autowired
    private BeaconCacheClient cacheClient;

    private final String CLIENT_FILTERS = "clientFilters";
    private final String SEPARATE = ",";

    public void strategy(StandardSubmit submit) {
        //  1.基于Redis获取客户对应的校验信息
        String filters = cacheClient.hget(CacheConstant.CLIENT_BUSINESS+submit.getApikey(),CLIENT_FILTERS);

        //  2.健壮性校验后，基于"，"分隔遍历
        String[ ] filterArray;
        if( filters != null && (filterArray = filters.split(SEPARATE)).length > 0) {
            // 到这，filterArray不为null，并且有数据
            for (String strategy : filterArray) {
                //3、 遍历时，从stringStrategyFilterMap中获取到需要执行的校验信息，执行
                StrategyFilter strategyFilter = strategyFilterMap.get(strategy);
                if (strategyFilter != null) {
                    strategyFilter.check(submit);
                }
            }
        }
    }
}
