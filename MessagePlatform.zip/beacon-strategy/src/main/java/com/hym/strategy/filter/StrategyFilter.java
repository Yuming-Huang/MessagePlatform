package com.hym.strategy.filter;

import com.hym.model.StandardSubmit;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 18:40
 * @Description: com.hym.strategy.filter
 * @version: 1.0
 */
public interface StrategyFilter {
    /**
     * 校验！！！！
     * @param submit
     */
    void check(StandardSubmit submit);
}
