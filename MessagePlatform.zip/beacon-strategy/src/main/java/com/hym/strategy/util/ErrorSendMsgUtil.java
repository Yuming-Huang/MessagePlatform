package com.hym.strategy.util;

import com.hym.constant.CacheConstant;
import com.hym.constant.RabbitMQConstants;
import com.hym.constant.StrategyConstant;
import com.hym.enums.ExceptionEnums;
import com.hym.model.StandardReport;
import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.hym.constant.StrategyConstant.CALLBACK_CODE;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 17:16
 * @Description: com.hym.strategy.util
 * @version: 1.0
 */
@Component
public class ErrorSendMsgUtil {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private BeaconCacheClient cacheClient;

    /**
     * 策略模块校验未通过，发送写日志操作
     * @param submit
     */
    public void sendWriteLog(StandardSubmit submit) {
        submit.setReportState(StrategyConstant.REPORT_FAILURE);
        // 发送消息到写日志队列
        rabbitTemplate.convertAndSend(RabbitMQConstants.SMS_WRITE_LOG,submit);
    }

    /**
     * 策略模块校验未通过，发送状态报告操作
     */
    public void sendPushReport(StandardSubmit submit) {
        //  查询当前客户的isCallback的数值
        Integer isCallback = Integer.valueOf(cacheClient.hget(CacheConstant.CLIENT_BUSINESS+submit.getApikey(),StrategyConstant.IS_CALLBACK));
        //  查看是否需要给客户一个回调
        if (isCallback == CALLBACK_CODE) {
            String url = cacheClient.hget(CacheConstant.CLIENT_BUSINESS+submit.getApikey(), StrategyConstant.CALLBACK_URL);
            if (StringUtils.isNotBlank(url)) {
                StandardReport report = new StandardReport();
                BeanUtils.copyProperties(submit, report);
                report.setIsCallback(CALLBACK_CODE);
                report.setCallbackUrl(url);
                rabbitTemplate.convertAndSend(RabbitMQConstants.SMS_PUSH_REPORT,report);
            }
        }
    }


}
