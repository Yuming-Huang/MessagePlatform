package com.hym.strategy.util;

import com.hym.model.StandardSubmit;

import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 18:08
 * @Description: com.hym.util
 * @version: 1.0
 */
public class ChannelTransferUtil {
    public static Map transfer(StandardSubmit submit, Map channel) {
        return channel;
    }
}
