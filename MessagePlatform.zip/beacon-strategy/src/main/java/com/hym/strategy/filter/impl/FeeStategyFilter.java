package com.hym.strategy.filter.impl;

import com.hym.constant.CacheConstant;
import com.hym.enums.ExceptionEnums;
import com.hym.exception.StrategyException;
import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import com.hym.strategy.filter.StrategyFilter;
import com.hym.strategy.util.ClientBalanceUtil;
import com.hym.strategy.util.ErrorSendMsgUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 12:40
 * @Description: com.hym.strategy.filter.impl
 * @version: 1.0
 */
@Component(value = "fee")
@Slf4j
public class FeeStategyFilter implements StrategyFilter {

    @Autowired
    private ErrorSendMsgUtil errorSendMsgUtil;

    @Autowired
    private BeaconCacheClient cacheClient;

    private final String BALANCE = "balance";


    @Override
    public void check(StandardSubmit submit) {
        log.info("【策略模块-扣费校验】   校验ing…………");
        //  1.基于传过来的参数查询ClientId和本次发送短信的费用fee
        Long fee = submit.getFee();
        Long clientId = submit.getClientId();

        //  2.预先使用decr扣除余额，获取当前客户的欠费金额的限制
        Long amount = cacheClient.hIncrBy(CacheConstant.CLIENT_BALANCE + clientId, BALANCE, -fee);
        Long amountLimit = ClientBalanceUtil.getClientAmountLimit(submit.getClientId());

        //  3.判断扣减过后的金额，是否超出了金额限制
        if(amount < amountLimit){
            //  4.如果超过阈值，则需要先把扣除的钱回填，并阻止本次消息发送
            cacheClient.hIncrBy(CacheConstant.CLIENT_BALANCE + clientId, BALANCE, fee);
            // ===============  发送状态错误日志  ==============
            submit.setErrorMsg(ExceptionEnums.BALANCE_NOT_ENOUGH.getMsg());
            errorSendMsgUtil.sendWriteLog(submit);
            // ===============  发送状态错误报告消息  ==============
            errorSendMsgUtil.sendPushReport(submit);
            throw new StrategyException(ExceptionEnums.BALANCE_NOT_ENOUGH);
        }
        log.info("【策略模块-扣费校验】   扣费成功！！");
    }
}
