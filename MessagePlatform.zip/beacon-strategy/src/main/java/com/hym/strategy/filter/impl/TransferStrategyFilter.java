package com.hym.strategy.filter.impl;

import com.hym.model.StandardSubmit;
import com.hym.strategy.client.BeaconCacheClient;
import com.hym.strategy.filter.StrategyFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.hym.constant.CacheConstant.TRANSFER;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 22:21
 * @Description: com.hym.strategy.filter.impl
 * @version: 1.0
 */
@Service(value = "transfer")
@Slf4j
public class TransferStrategyFilter implements StrategyFilter {

    @Autowired
    private BeaconCacheClient beaconCacheClient;

    /**
     * 校验！！！！
     *
     * @param submit
     */
    @Override
    public void check(StandardSubmit submit) {
        String mobile = submit.getMobile();
        String isTransfer = beaconCacheClient.getString(TRANSFER+mobile);

        //3、如果存在携号转网，设置运营商信息
        if(!StringUtils.isEmpty(isTransfer)){
            // 代表携号转网了
            submit.setOperatorId(Integer.valueOf(isTransfer));
            submit.setIsTransfer(true);
            log.info("【策略模块-携号转网策略】   当前手机号携号转网了！");
            return;
        }

        log.info("【策略模块-携号转网策略】   嘛事没有！");
    }
}
