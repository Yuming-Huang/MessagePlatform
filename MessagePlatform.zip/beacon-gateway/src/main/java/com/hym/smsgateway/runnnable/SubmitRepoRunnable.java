package com.hym.smsgateway.runnnable;

import com.hym.constant.RabbitMQConstants;
import com.hym.constant.StrategyConstant;
import com.hym.model.StandardReport;
import com.hym.model.StandardSubmit;
import com.hym.smsgateway.netty4.entity.CmppSubmitResp;
import com.hym.smsgateway.util.SpringUtil;
import com.hym.util.CMPP2SubimitUtil;
import com.hym.util.CMPPDeliverMapUtil;
import com.hym.util.CMPPSubmitMapUtil;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 16:42
 * @Description: com.hym.smsgateway.runnnable
 * @version: 1.0
 */
public class SubmitRepoRunnable implements Runnable{

    private RabbitTemplate rabbitTemplate = SpringUtil.getBeanByClass(RabbitTemplate.class);

    private CmppSubmitResp submitResp;

    public SubmitRepoRunnable(CmppSubmitResp submitResp) {
        this.submitResp = submitResp;
    }

    @Override
    public void run() {

        // 1.拿到自增Id，并且从ConcurrentHashMap中获取到存储submit
        StandardSubmit submit = CMPPSubmitMapUtil.remove(submitResp.getSequenceId());

        //  2.根据运营商返回的result，确认短信状态并且封装submit
        int result = submitResp.getResult();
        if(result != 0){
            // 说明运营商的提交应答中反馈的失败的情况
            String resultMessage = CMPP2SubimitUtil.getMsgByResult(result);
            submit.setReportState(StrategyConstant.REPORT_FAILURE);
            submit.setErrorMsg(resultMessage);
        } else {
            //  如果没进到if中，说明运营商已经正常的接收了发送短信的任务，完成封装report操作
            //  3.将submit封装为Report，临时存储，以便运营商返回状态码时，可以再次获取到信息
            StandardReport report = new StandardReport();
            BeanUtils.copyProperties(submit,report);
            CMPPDeliverMapUtil.put(submitResp.getMsgId()+"", report);
        }
        //  4.将封装好的submit直接扔进RabbitMQ中，让搜索模块记录信息
        rabbitTemplate.convertAndSend(RabbitMQConstants.SMS_WRITE_LOG,submit);
    }
}
