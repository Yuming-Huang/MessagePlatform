package com.hym.smsgateway;

import cn.hippo4j.core.enable.EnableDynamicThreadPool;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/22 - 03 - 22 - 11:24
 * @Description: com.hym.smsgateway
 * @version: 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableDynamicThreadPool
@ComponentScan(basePackages = {"com.hym.*"})
@EnableFeignClients
public class GatewayStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(GatewayStarterApp.class, args);
    }
}
