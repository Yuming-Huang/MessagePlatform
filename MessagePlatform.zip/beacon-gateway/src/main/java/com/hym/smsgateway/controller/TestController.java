package com.hym.smsgateway.controller;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 13:37
 * @Description: com.hym.smsgateway.controller
 * @version: 1.0
 */
public class TestController {
}
