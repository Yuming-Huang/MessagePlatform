package com.hym.smsgateway.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 17:45
 * @Description: com.hym.strategy.client
 * @version: 1.0
 */
@FeignClient(value = "beacon-cache")
public interface BeaconCacheClient {
    @GetMapping("/cache/hget/{key}/{field}")
    Integer hgetInteger(@PathVariable(value = "key")String key, @PathVariable(value = "field")String field);

    @GetMapping("/cache/hget/{key}/{field}")
   String hgetString(@PathVariable(value = "key")String key, @PathVariable(value = "field")String field);
}
