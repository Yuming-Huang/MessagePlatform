package com.hym;

import com.hym.client.CacheClient;
import com.hym.mapper.MobileDirtywordMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static com.hym.constant.CacheConstant.DIRTY_WORD;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 10:27
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class MobileDirtyMapperTest {
    @Autowired
    private MobileDirtywordMapper mobileDirtywordMapper;

    @Autowired
    private CacheClient cacheClient;

    @Test
    public void findDirtyWord() {
        List<String> dirtyWord = mobileDirtywordMapper.findDirtyword();
        cacheClient.saddStr(DIRTY_WORD,dirtyWord.toArray(new String[ ]{}));
    }
}
