package com.hym;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hym.client.CacheClient;
import com.hym.constant.CacheConstant;
import com.hym.entity.Channel;
import com.hym.mapper.ChannelMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 16:51
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class ChannelMapperTest {

    @Autowired
    private ChannelMapper channelMapper;

    @Autowired
    private CacheClient cacheClient;

    @Test
    void testChannelToRedis() {
        List<Channel> channels = channelMapper.selectAll();
        for (Channel channel : channels) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map map = objectMapper.convertValue(channel, Map.class);
            cacheClient.hmset(CacheConstant.CHANNEL+channel.getId(), map);
        }
    }
}
