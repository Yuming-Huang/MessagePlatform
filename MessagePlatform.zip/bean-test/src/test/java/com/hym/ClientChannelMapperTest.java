package com.hym;

import cn.hutool.json.JSONString;
import cn.hutool.json.JSONUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hym.client.CacheClient;
import com.hym.entity.ClientChannel;
import com.hym.mapper.ClientChannelMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

import static com.hym.constant.CacheConstant.CLIENT_CHANNEL;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 17:13
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class ClientChannelMapperTest {

    @Autowired
    private ClientChannelMapper clientChannelMapper;

    @Autowired
    private CacheClient cacheClient;

    @Test
    public void testClientChannelToRedis() {
        List<ClientChannel> clientChannels = clientChannelMapper.findAll();
        for (ClientChannel clientChannel: clientChannels) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map map = objectMapper.convertValue(clientChannel, Map.class);
            cacheClient.sadd(CLIENT_CHANNEL+clientChannel.getClientId(), map);
        }
    }
}
