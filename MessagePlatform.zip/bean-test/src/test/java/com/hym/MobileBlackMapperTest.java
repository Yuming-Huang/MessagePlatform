package com.hym;

import com.hym.client.CacheClient;
import com.hym.entity.MobileBlack;
import com.hym.mapper.MobileBlackMapper;
import com.hym.mapper.MobileDirtywordMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 18:24
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class MobileBlackMapperTest {

    @Autowired
    private MobileBlackMapper mobileBlackMapper;

    @Autowired
    private CacheClient cacheClient;

    @Test
    public void findAll() {
        List<MobileBlack> mobileBlackList = mobileBlackMapper.findAll();
        for (MobileBlack mobileBlack : mobileBlackList) {
            if(mobileBlack.getClientId() == 0){
                // 平台级别的黑名单   black:手机号   作为key
                cacheClient.set("black:" + mobileBlack.getBlackNumber(),"1");
            }else{
                // 客户级别的黑名单   black:clientId:手机号
                cacheClient.set("black:" + mobileBlack.getClientId() + ":" +mobileBlack.getBlackNumber(),"1");
            }
        }
    }

}
