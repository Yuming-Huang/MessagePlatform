package com.hym;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hym.client.CacheClient;
import com.hym.entity.ClientBusiness;
import com.hym.entity.ClientSign;
import com.hym.mapper.ClientBusinessMapper;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/15 - 03 - 15 - 21:32
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest

public class ClientBusinessMapperTest {

    @Autowired
    private CacheClient cacheClient;

    @Autowired
    private ClientBusinessMapper clientBusinessMapper;

    @Test
    public void findById() throws JsonProcessingException {
        ClientBusiness cb = clientBusinessMapper.findById(1L);
        ObjectMapper objectMapper = new ObjectMapper();
        Map map = objectMapper.readValue(objectMapper.writeValueAsString(cb), Map.class);
        cacheClient.hmset("client_business:" + cb.getApikey(),map);
    }


}