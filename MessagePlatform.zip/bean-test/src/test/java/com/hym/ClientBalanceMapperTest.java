package com.hym;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hym.client.CacheClient;
import com.hym.entity.ClientBalance;
import com.hym.mapper.ClientBalanceMapper;
import net.minidev.json.JSONUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 14:04
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class ClientBalanceMapperTest {

    @Autowired
    private ClientBalanceMapper mapper;

    @Autowired
    private CacheClient cacheClient;


    @Test
    public void findByClientId() throws JsonProcessingException {
        ClientBalance balance = mapper.findByClientId(1L);
        System.out.println(balance);
        ObjectMapper objectMapper = new ObjectMapper();
        Map map = objectMapper.readValue(objectMapper.writeValueAsString(balance), Map.class);
        cacheClient.hmset("client_balance:1", map);
    }
}