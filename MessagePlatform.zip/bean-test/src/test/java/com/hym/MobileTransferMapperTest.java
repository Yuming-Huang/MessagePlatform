package com.hym;

import com.hym.client.CacheClient;
import com.hym.entity.MobileTransfer;
import com.hym.mapper.MobileTransferMapper;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 22:17
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class MobileTransferMapperTest {

    @Autowired
    private MobileTransferMapper mapper;

    @Autowired
    private CacheClient cacheClient;


    @Test
    public void findAll() {
        List<MobileTransfer> list = mapper.findAll();

        for (MobileTransfer mobileTransfer : list) {
            cacheClient.set("transfer:" + mobileTransfer.getTransferNumber(), mobileTransfer.getNowIsp());
        }
    }
}
