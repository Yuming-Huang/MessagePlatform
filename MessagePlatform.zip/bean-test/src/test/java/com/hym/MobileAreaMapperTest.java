package com.hym;

import com.hym.client.CacheClient;
import com.hym.constant.CacheConstant;
import com.hym.entity.MobileArea;
import com.hym.mapper.MobileAreaMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 20:34
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class MobileAreaMapperTest {

    @Autowired
    private CacheClient cacheClient;

    @Autowired
    private MobileAreaMapper mobileAreaMapper;

    @Test
    public void findAll() {
        List<MobileArea> list = mobileAreaMapper.findAll();
        Map map = new HashMap(list.size());
        for (MobileArea mobileArea : list) {
            map.put(CacheConstant.PHASE + mobileArea.getMobileNumber(), mobileArea.getMobileArea() + "," + mobileArea.getMobileType());
        }
        cacheClient.pipelineString(map);
    }
}
