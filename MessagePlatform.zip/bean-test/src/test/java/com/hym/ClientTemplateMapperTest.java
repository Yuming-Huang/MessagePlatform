package com.hym;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hym.client.CacheClient;
import com.hym.entity.ClientTemplate;
import com.hym.mapper.ClientTemplateMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 13:56
 * @Description: com.hym.mapper
 * @version: 1.0
 */
@SpringBootTest
public class ClientTemplateMapperTest {

    @Autowired
    private ClientTemplateMapper clientTemplateMapper;

    @Autowired
    private CacheClient cacheClient;

    @Test
    void findBySignId() {
        List<ClientTemplate> ct1 = clientTemplateMapper.findBySignId(15L);
        List<ClientTemplate> ct2 = clientTemplateMapper.findBySignId(24L);
        ct1.stream().forEach(System.out::println);
        ObjectMapper objectMapper = new ObjectMapper();
        List<Map> value = ct1.stream().map(ct -> {
            try {
                return objectMapper.readValue(objectMapper.writeValueAsString(ct), Map.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
                return null;
            }
        }).collect(Collectors.toList());
        cacheClient.sadd("client_template:15",value.toArray(new Map[]{}));
    }
}