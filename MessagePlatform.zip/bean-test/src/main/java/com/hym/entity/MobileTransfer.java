package com.hym.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 22:15
 * @Description: com.hym.mapper
 * @version: 1.0
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MobileTransfer {

    //  手机号码
    private String transferNumber;

    //  最终运营商
    private String nowIsp;
}
