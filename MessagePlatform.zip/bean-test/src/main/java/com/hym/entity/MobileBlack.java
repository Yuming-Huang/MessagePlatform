package com.hym.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
import java.io.Serializable;

/**
 * 手机号黑名单表(MobileBlack)实体类
 *
 * @author makejava
 * @since 2025-03-19 18:21:08
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MobileBlack implements Serializable {
    private static final long serialVersionUID = 508064059876917101L;
/**
     * 主键
     */
    private Long id;
/**
     * 黑名单手机号
     */
    private String blackNumber;
/**
     * 录入方式 0-手动导入 1-第三方API 2-用户退订
     */
    private Integer blackType;
/**
     * 黑名单类型 0-全局黑名单  其他-客户黑名单
     */
    private Integer clientId;
/**
     * 创建时间，默认系统时间
     */
    private Date created;
/**
     * 创建人id
     */
    private Long createId;
/**
     * 修改时间，默认系统时间
     */
    private Date updated;
/**
     * 修改人id
     */
    private Long updateId;
/**
     * 是否删除 0-未删除 ， 1-已删除
     */
    private Integer isDelete;
/**
     * 备用字段1
     */
    private String extend1;
/**
     * 备用字段2
     */
    private String extend2;
/**
     * 备用字段3
     */
    private String extend3;
/**
     * 备用字段4
     */
    private String extend4;


}

