package com.hym.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
import java.io.Serializable;

/**
 * 客户通道表(ClientChannel)实体类
 *
 * @author makejava
 * @since 2025-03-20 16:34:03
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ClientChannel implements Serializable {

    private static final long serialVersionUID = -87019624518598847L;
    /**
     * 客户id，对应client_business表
     */
    private Long clientId;
    /**
     * 通道id，对应channel表
     */
    private Long channelId;
    /**
     * 通道权重
     */
    private Integer clientChannelWeight;

    /**
     * 下发扩展号 如：通道接入号为1069886，后面可以扩展数字，最长不超过20位
     */
    private String clientChannelNumber;
    /**
     * 是否启动 0-启用中 1-已停用
     */
    private Integer isAvailable;

    /**
     * 是否删除 0-未删除 ， 1-已删除
     */
    private Integer isDelete;

}

