package com.hym.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 16:32
 * @Description: com.hym.entity
 * @version: 1.0
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Channel implements Serializable {
    private static final long serialVersionUID = -15518768106677233L;
    /**
     * 主键
     */
    private Long id;
    /**
     * 通道名称 如：北京移动、上海联通、深圳电信
     */
    private String channelName;
    /**
     * 通道类型：0-三网 1-移动 2-联通 3-电信
     */
    private Integer channelType;
    /**
     * 通道地区 如：北京 北京、湖北 荆门
     */
    private String channelArea;
    /**
     * 地区号段
     */
    private String channelAreaCode;
    /**
     * 通道短信成本价格（厘/条）
     */
    private Long channelPrice;
    /**
     * 通道协议类型 1-cmpp、2-sgip、3-smgp
     */
    private Integer channelProtocal;
    /**
     * 通道IP地址
     */
    private String channelIp;
    /**
     * 通道端口号
     */
    private Integer channelPort;
    /**
     * 通道账号
     */
    private String channelUsername;
    /**
     * 通道密码
     */
    private String channelPassword;
    /**
     * 账户接入号，如1069777、10684376
     */
    private String channel_Number;
    /**
     * 是否启动 0-已停用 1-启用中
     */
    private Integer isAvailable;
    /**
     * 创建时间，默认系统时间
     */
    private Date created;
    /**
     * 创建人id
     */
    private Long createId;
    /**
     * 修改时间，默认系统时间
     */
    private Date updated;
    /**
     * 修改人id
     */
    private Long updateId;
    /**
     * 是否删除 0-未删除 ， 1-已删除
     */
    private Integer isDelete;
    /**
     * 备用字段1
     */
    private String extend1;
    /**
     * 备用字段2
     */
    private String extend2;
    /**
     * 备用字段3
     */
    private String extend3;
    /**
     * 备用字段4
     */
    private String extend4;
}
