package com.hym.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 20:36
 * @Description: com.hym.entity
 * @version: 1.0
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MobileArea {

    private String mobileNumber;

    private String mobileArea;

    private String mobileType;
}
