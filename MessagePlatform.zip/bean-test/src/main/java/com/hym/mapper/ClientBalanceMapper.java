package com.hym.mapper;

import com.hym.entity.ClientBalance;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 14:03
 * @Description: com.hym
 * @version: 1.0
 */
public interface ClientBalanceMapper {

    @Select("select * from client_balance where client_id = #{clientId}")
    ClientBalance findByClientId(@Param("clientId")Long clientId);

}
