package com.hym.mapper;

import com.hym.entity.ClientBusiness;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/15 - 03 - 15 - 21:17
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface ClientBusinessMapper {

    @Select("select * from client_business where id = #{id}")
    ClientBusiness findById(@Param("id") Long id);

}