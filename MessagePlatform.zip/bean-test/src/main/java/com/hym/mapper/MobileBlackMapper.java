package com.hym.mapper;

import com.hym.entity.MobileBlack;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 18:19
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface MobileBlackMapper {
    @Select("select black_number,client_id from mobile_black where is_delete = 0")
    List<MobileBlack> findAll();
}
