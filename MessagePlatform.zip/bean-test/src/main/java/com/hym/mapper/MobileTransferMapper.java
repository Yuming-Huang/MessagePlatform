package com.hym.mapper;

import com.hym.entity.MobileTransfer;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 22:11
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface MobileTransferMapper {
    @Select("SELECT transfer_number, now_isp FROM mobile_transfer where is_transfer = 1 and is_delete = 0")
    List<MobileTransfer> findAll();
}
