package com.hym.mapper;

import com.hym.entity.ClientTemplate;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 13:53
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface ClientTemplateMapper {

    @Select("select * from client_template where sign_id = #{signId}")
    List<ClientTemplate> findBySignId(@Param("signId")Long signId);
}
