package com.hym.mapper;

import com.hym.entity.ClientChannel;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 16:40
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface ClientChannelMapper {

    @Select("select  * from client_channel where is_delete = 0")
    List<ClientChannel> findAll();
}
