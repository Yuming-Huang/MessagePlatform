package com.hym.mapper;

import com.hym.entity.ClientSign;
import com.hym.entity.ClientTemplate;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 10:46
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface ClientSignMapper {
    @Select("select * from client_sign where client_id = #{clientId}")
    List<ClientSign> findByClientId(@Param("clientId")Long clientId);


}
