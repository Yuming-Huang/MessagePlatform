package com.hym.mapper;

import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 1:30
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface MobileDirtywordMapper {
    @Select("select  dirtyword from mobile_dirtyword ")
    List<String> findDirtyword();
}
