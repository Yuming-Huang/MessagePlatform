package com.hym.mapper;

import com.hym.entity.MobileArea;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 20:36
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface MobileAreaMapper {

    @Select( "SELECT mobile_number, mobile_area, mobile_type FROM mobile_area ")
    List<MobileArea>  findAll ();
}
