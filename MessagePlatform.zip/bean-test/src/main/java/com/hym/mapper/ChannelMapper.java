package com.hym.mapper;

import com.hym.entity.Channel;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/20 - 03 - 20 - 16:40
 * @Description: com.hym.mapper
 * @version: 1.0
 */
public interface ChannelMapper {
    @Select("select * from channel where is_delete = 0")
    List<Channel> selectAll();
}
