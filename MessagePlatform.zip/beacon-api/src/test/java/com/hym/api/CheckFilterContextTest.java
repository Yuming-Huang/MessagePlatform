package com.hym.api;

import com.hym.api.filter.CheckFilterContext;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 15:28
 * @Description: com.hym
 * @version: 1.0
 */
@SpringBootTest
public class CheckFilterContextTest {
    @Autowired
    private CheckFilterContext checkFilterContext;

    @Test
    void contextLoads() {
        Object o = new Object();
        checkFilterContext.check(o);
    }
}
