package com.hym.api.filter.impl;

import com.hym.api.filter.CheckFilter;
import com.hym.api.utils.PhoneFormatCheckUtil;
import com.hym.enums.ExceptionEnums;
import com.hym.exception.ApiException;
import com.hym.model.StandardSubmit;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 15:50
 * @Description: 校验手机号的格式合法性
 * @version: 1.0
 */
@Service(value = "mobile")
@Slf4j
public class MobileCheck implements CheckFilter {

    @Override
    public void check(StandardSubmit submit) {
        log.info("【接口模块-校验手机号】   校验ing…………");
        String mobile = submit.getMobile();
        if(!StringUtils.isEmpty(mobile) && PhoneFormatCheckUtil.isChinaPhone(mobile)){
            // 如果校验进来，代表手机号么得问题
            log.info("【接口模块-校验手机号】   手机号格式合法 mobile = {}",mobile);
            return;
        }
        log.info("【接口模块-校验手机号】   手机号格式不正确 mobile = {}",mobile);
        throw new ApiException(ExceptionEnums.ERROR_MOBILE);
    }
}
