package com.hym.api.filter.impl;

import com.hym.api.client.BeaconCacheClient;
import com.hym.api.filter.CheckFilter;
import com.hym.constant.CacheConstant;
import com.hym.enums.ExceptionEnums;
import com.hym.exception.ApiException;
import com.hym.model.StandardSubmit;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 15:50
 * @Description: 校验请求的ip地址是否是白名单
 * @version: 1.0
 */
@Service(value = "ip")
@Slf4j
public class IPCheck implements CheckFilter {

    @Autowired
    private BeaconCacheClient cacheClient;

    private final String IP_ADDRESS = "ipAddress";

    @Override
    public void check(StandardSubmit submit) {
        log.info("[接口模块-校验ip] 校验ing-----------");
        //  1.根据CacheClient根据客户的apikey以及ipAddress去查询客户的IP白名单
        String ips = cacheClient.hGetString(CacheConstant.CLIENT_BUSINESS + submit.getApikey(), IP_ADDRESS);
        submit.setIpOrder(ips);

        //  2.判断白名单是否为空或ip地址是否在白名单内
        if(StringUtils.isBlank(ips)  || ips.contains(submit.getRealIP())) {
            log.info("【接口模块-校验ip】  客户端请求IP合法！");
            return;
        }

        //  3. IP白名单不为空，并且客户端请求不在IP报名单内
        log.info("【接口模块-校验ip】  请求的ip不在白名单内");
        throw new ApiException(ExceptionEnums.IP_NOT_WHITE);
    }

}
