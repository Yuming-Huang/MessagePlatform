package com.hym.api.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 16:12
 * @Description: 设置RabbitTemplate的confirm&return机制
 * @version: 1.0
 */
@Slf4j
@Configuration
public class RabbitTemplateConfig {
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        //  1.构建RabbitTemplate的实例
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        //  2.设置连接工厂
        rabbitTemplate.setConnectionFactory(connectionFactory);
        //  3.设置消息路由
        rabbitTemplate.setMandatory(true);
        //  3.设置confirm回调函数
        rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {
            @Override
            public void confirm(CorrelationData correlationData, boolean ack, String cause) {
                // ack为false，代表消息没有发送到exchange。
                if(!ack){
                    log.error("【接口模块-发送消息】 消息没有发送到交换机，correlationData = {}，cause = {}",correlationData,cause);
                }
            }
        });
        //  4.设置return回调函数
        rabbitTemplate.setReturnCallback(new RabbitTemplate.ReturnCallback() {

            @Override
            public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
                log.error("【接口模块-发送消息】 消息没有路由到指定的Queue。 message = {},exchange = {},routingKey = {}",
                        new String(message.getBody()),exchange,routingKey);
            }
        });
        //  5.返回rabbitTemplate
        return rabbitTemplate;
    }

}
