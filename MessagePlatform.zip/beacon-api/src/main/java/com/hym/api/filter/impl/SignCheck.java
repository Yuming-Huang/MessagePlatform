package com.hym.api.filter.impl;

import com.hym.api.client.BeaconCacheClient;
import com.hym.api.filter.CheckFilter;
import com.hym.constant.ApiConstant;
import com.hym.constant.CacheConstant;
import com.hym.enums.ExceptionEnums;
import com.hym.exception.ApiException;
import com.hym.model.StandardSubmit;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 15:50
 * @Description: 校验短信的签名
 * @version: 1.0
 */
@Service(value = "sign")
@Slf4j
public class SignCheck implements CheckFilter {

    @Autowired
    private BeaconCacheClient cacheClient;

    /**
     * 截取签名的开始索引
     */
    private final int SIGN_START_INDEX = 1;

    /**
     * 客户存储签名信息的字段
     */
    private final String CLIENT_SIGN_INFO = "signInfo";

    /**
     * 客户存储签名信息的字段
     */
    private final String SIGN_ID = "id";

    @Override
    public void check(StandardSubmit submit) {
        log.info("[接口模块-校验sign]  校验ing-----------");
        //  1.先从客户端发送请求中携带的短信内容中，判断是否有使用【】携带了签名
        String text = submit.getText();
        if(! text.startsWith(ApiConstant.SIGN_PREFIX) || ! text.contains(ApiConstant.SIGN_SUFFIX)){
            log.info("【接口模块-校验签名】   无可用签名 text = {}",text);
            throw new ApiException(ExceptionEnums.ERROR_SIGN);
        }
        //  2.如果携带了签名，需要将签名截取出来
        String sign = text.substring(SIGN_START_INDEX, text.indexOf(ApiConstant.SIGN_SUFFIX));
        if(StringUtils.isEmpty(sign)){
            log.info("【接口模块-校验签名】   无可用签名 text = {}",text);
            throw new ApiException(ExceptionEnums.ERROR_SIGN);
        }

        //  3.基于Redis查询当前客户绑定的所有签名信息
        Set<Map> set = cacheClient.smember(CacheConstant.CLIENT_SIGN + submit.getClientId());
        if(set == null || set.size() == 0){
            log.info("【接口模块-校验签名】   无可用签名 text = {}",text);
            throw new ApiException(ExceptionEnums.ERROR_SIGN);
        }
        //  4.在客户有绑定了签名的情况下，去做校验
        //  判断
        for (Map map : set) {
            if (sign.equals(map.get(CLIENT_SIGN_INFO))) {
                //  匹配上具体的签名信息
                submit.setSign(sign);
                submit.setSignId(Long.parseLong(map.get(SIGN_ID) + ""));
                log.info("【接口模块-校验签名】   找到匹配的签名 sign = {}", sign);
                return;
            }
            //  5.到了最后，说明签名不匹配，直接告辞
            log.info("【接口模块-校验签名】   无可用签名 text = {}", text);
            throw new ApiException(ExceptionEnums.ERROR_SIGN);
        }
    }
}
