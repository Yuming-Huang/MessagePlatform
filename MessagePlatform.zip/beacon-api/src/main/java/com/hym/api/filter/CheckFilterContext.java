package com.hym.api.filter;

import com.hym.model.StandardSubmit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 16:01
 * @Description: com.hym.api.filter
 * @version: 1.0
 */
@Component
@RefreshScope
public class CheckFilterContext {
    //Spring的IOC会将对象全部都放到Map集合中
    //基于4.0中spring提供的反省注解，基于Map只拿到需要的类型对象即可
    @Autowired
    private Map<String, CheckFilter> checkFiltersMap;

    @Value("${filters:apikey,ip,sign,template}")
    private String filters;

    public void check(StandardSubmit submit){
        //  1.将获取到的filters基于，做切分
        String[] filterArray = filters.split(",");
        for (String filter : filterArray) {
            CheckFilter checkFilter = checkFiltersMap.get(filter);
            checkFilter.check(submit);
        }

    }

}
