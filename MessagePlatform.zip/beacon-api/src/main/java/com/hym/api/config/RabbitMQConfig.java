package com.hym.api.config;

import com.hym.constant.RabbitMQConstants;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 16:12
 * @Description: com.hym.api.config
 * @version: 1.0
 */
@Configuration
public class RabbitMQConfig {
    /**
     * 接口模块发送消息到策略模块的队列
     * @return
     */
    @Bean
    public Queue preSendQueue(){
        return QueueBuilder.durable(RabbitMQConstants.SMS_PRE_SEND).build();
    }
}
