package com.hym.api.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 16:58
 * @Description: com.hym.api.enums
 * @version: 1.0
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum SmsCodeEnum {
    PARAMETER_ERROR(-10,"参数不合法！");

    private Integer code;
    private String msg;

}
