package com.hym.api.utils;

import com.hym.api.vo.ResultVO;
import com.hym.exception.ApiException;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 16:55
 * @Description: com.hym.api.utils
 * @version: 1.0
 */
public class R {
    public static ResultVO ok(){
        ResultVO r = new ResultVO();
        r.setCode(0);
        r.setMsg("接收成功");
        return r;
    }
    public static ResultVO error(Integer code, String msg){
        ResultVO r = new ResultVO();
        r.setCode(code);
        r.setMsg(msg);
        return r;
    }

    public static ResultVO error(ApiException ex){
        ResultVO r = new ResultVO();
        r.setCode(ex.getCode());
        r.setMsg(ex.getMessage());
        return r;
    }
}
