package com.hym.api.filter;

import com.hym.model.StandardSubmit;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 15:49
 * @Description: com.hym.api.filter
 * @version: 1.0
 */
public interface CheckFilter {

    void check(StandardSubmit submit);
}
