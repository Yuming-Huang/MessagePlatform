package com.hym.api.vo;

import lombok.Data;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 16:53
 * @Description: com.hym.api.vo
 * @version: 1.0
 */
@Data
public class ResultVO {
    private Integer code;

    private String msg;

    private Integer count;

    private Long fee;

    private String uid;

    private String sid;
}
