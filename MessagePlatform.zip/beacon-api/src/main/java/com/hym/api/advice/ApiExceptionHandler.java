package com.hym.api.advice;

import com.hym.api.utils.R;
import com.hym.api.vo.ResultVO;
import com.hym.exception.ApiException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 15:29
 * @Description: com.hym.api.advice
 * @version: 1.0
 */
@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(ApiException.class)
    public ResultVO apiException(ApiException ex) {
        return R.error(ex);
    }
}
