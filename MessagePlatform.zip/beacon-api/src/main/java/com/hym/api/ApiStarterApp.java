package com.hym.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 13:48
 * @Description: com.hym.api
 * @version: 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@ComponentScan(basePackages = {"com.hym"})
public class ApiStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(ApiStarterApp.class, args);
    }
}
