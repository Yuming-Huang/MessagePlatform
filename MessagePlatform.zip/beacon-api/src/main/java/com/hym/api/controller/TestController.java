package com.hym.api.controller;

import com.hym.api.filter.CheckFilterContext;
import com.hym.model.StandardSubmit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 16:26
 * @Description: com.hym.api.controller
 * @version: 1.0
 */
@Controller
public class TestController {

    @Autowired
    private CheckFilterContext checkFilterContext;


    /**
     * @Description:校验动态过滤链条
     * @Param: []
     * @return: void
     * @Author: YumingHuang
     * @Date: 2025/3/11
     */
    @GetMapping("/api/test")
    public void test() {
        System.out.println("=======");
        StandardSubmit submit = new StandardSubmit();
        checkFilterContext.check(submit);
    }
}
