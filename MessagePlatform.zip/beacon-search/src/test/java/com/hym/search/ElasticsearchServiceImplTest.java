package com.hym.search;

import com.hym.search.service.SearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/26 - 03 - 26 - 14:02
 * @Description: com.hym.search.service
 * @version: 1.0
 */
@SpringBootTest
class ElasticsearchServiceImplTest {
    @Autowired
    private SearchService searchService;
    @Test
    void exists() throws IOException {
        searchService.exists("sms_submit_log_2025","313991356261335040");
    }
}