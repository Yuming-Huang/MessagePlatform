package com.hym.search;

import com.hym.search.service.SearchService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/21 - 03 - 21 - 16:33
 * @Description: com.hym.search
 * @version: 1.0
 */
@SpringBootTest
public class SearchServiceTest {

    @Autowired
    private SearchService searchService;

    @Test
    public void index() throws IOException {
        searchService.index("sms_submit_log_2025","2","{\"client\":2}");
    }
}