package com.hym.search.Vo;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/11 - 03 - 11 - 17:26
 * @Description: com.hym.model
 * @version: 1.0
 */

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 在接口模块-策略模块-短信网关模块需要做校验和封装的POJO类对象
 *
 * @author zjw
 * @description
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchStandardSubmit implements Serializable {

    private static final long serialVersionUID = -7309414482801235612L;

    /**
     * 针对当前短信的唯一标识，使用雪花算法
     */
    private Long sequenceId;

    /**
     * 客户端ID，基于apikey查询缓存模块得到客户Id
     */
    private Long clientId;

    /**
     * 客户端的ip白名单，查询缓存
     */
    private List<String> ipOrder;

    /**
     * 客户业务内的uid，客户请求传递
     */
    private String uid;

    /**
     * 目标手机号，客户请求传递
     */
    private String mobile;

    /**
     * 短信内容的签名，客户请求传递，只需要在短信内容中基于【 】获取出来
     */
    private String sign;

    /**
     * 短信内容，客户请求传递
     */
    private String text;

    /**
     * 短信的发送时间，当前系统时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime sendTime;

    /**
     * 当前短信的费用，计算短信内容文字，70个文字一条，超过部分，67个字一条
     */
    private Long fee;

    /**
     * 目标手机号的运营商（策略模块）
     * 手机号运营商： 1-移动 ；2-联通； 3-电信
     */
    private Integer operatorId;

    /**
     * 目标手机号的归属地区号  0451  0455（策略模块 三方查询不到 暂时忽略）
     */
    private Integer areaCode;

    /**
     * 目标手机号的归属地  哈尔滨，  绥化~（策略模块）
     */
    private String area;

    /**
     * 通道下发的源号码  106934985673485645（策略模块）
     */
    private String srcNumber;

    /**
     * 通道的id信息（策略模块）
     */
    private Long channelId;

    /**
     * 短信的发送状态， 0-等待ing，1-成功，2-失败，默认情况是0（策略模块）
     */
    private int reportState;

    /**
     * 短信发送失败的原因（策略模块）
     */
    private String errorMsg;

    /**
     * 获取到的客户端真实IP地址
     */
    private String realIP;

    /**
     * 客户端请求携带的apiKey
     */
    private String apikey;

    /**
     *  0-验证码短信 1-通知类短信 2-营销类短信
     */
    private Integer state;

    /**
     *  签名的Id
     */
    private Long signId;

    /**
     * 是否携号转网  0-没有携号转网 1-已经携号转网 （默认为0）
     */
    private Boolean isTransfer;

    /**
     * 针对一小时限流规则存储的系统时间毫秒值
     */
    private Long OneHourLimitMilli;
}
