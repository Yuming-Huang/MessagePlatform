package com.hym.search.mq;

import com.hym.model.StandardReport;
import com.hym.model.StandardSubmit;
import com.hym.search.service.SearchService;
import com.hym.search.utils.SearchUtils;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.hym.constant.RabbitMQConstants.SMS_GATEWAY_DEAD_QUEUE;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/26 - 03 - 26 - 13:10
 * @Description: com.hym.search.mq
 * @version: 1.0
 */
@Component
@Slf4j
public class SmsUpdateLogListener {

    @Autowired
    private SearchService searchService;

    @RabbitListener(queues = SMS_GATEWAY_DEAD_QUEUE)
    public void consume(StandardReport report, Channel channel, Message message) throws IOException {
        log.info("【搜索模块-修改日志】接收到修改日志的消息 report={}",report);
        //  1.设置report
        SearchUtils.set(report);

        //  2.更新数据
        Map<String, Object> doc = new HashMap<>();
        doc.put("reportState",report.getReportState());
        searchService.update(SearchUtils.INDEX +SearchUtils.getYear() , report.getSequenceId().toString(),doc);

        //  3.手动ack
        channel.basicAck(message.getMessageProperties().getDeliveryTag(),false);
    }
}
