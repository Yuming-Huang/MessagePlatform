package com.hym.search;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication
@EnableDiscoveryClient
public class SearchStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(SearchStarterApp.class, args);
    }
}