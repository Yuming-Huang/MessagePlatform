package com.hym.search.mq;

import com.hym.constant.RabbitMQConstants;
import com.hym.model.StandardSubmit;
import com.hym.search.Vo.SearchStandardSubmit;
import com.hym.search.service.SearchService;
import com.hym.search.utils.SearchUtils;
import com.hym.util.JsonUtil;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/21 - 03 - 21 - 15:25
 * @Description: com.hym.search.mq
 * @version: 1.0
 */
@Component
@Slf4j
public class SmsWriteLogListener {

    @Autowired
    private SearchService searchService;


    @RabbitListener(queues = RabbitMQConstants.SMS_WRITE_LOG)
    public void consume(StandardSubmit submit, Channel channel, Message message) throws IOException {
        //1、调用搜索模块的添加方法，完成添加操作
        log.info("接收到存储日志的信息   submit = {}", submit);

        //  补IpAddress的序列化问题
        SearchStandardSubmit newsubmit = new SearchStandardSubmit();
        BeanUtils.copyProperties(submit,newsubmit);
        String ips =  submit.getIpOrder();
        if( StringUtils.isNotBlank(ips) ){
            List<String> newIpOrders = Arrays.asList(ips.split(","));
            newsubmit.setIpOrder(newIpOrders);
        }
        searchService.index(SearchUtils.INDEX + SearchUtils.getYear(),newsubmit.getSequenceId().toString(), JsonUtil.objectToJson(newsubmit));

        //2、手动ack
        channel.basicAck(message.getMessageProperties().getDeliveryTag(),false);
    }

}
