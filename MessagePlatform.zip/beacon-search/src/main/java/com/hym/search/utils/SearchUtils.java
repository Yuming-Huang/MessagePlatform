package com.hym.search.utils;

import com.hym.model.StandardReport;

import java.time.LocalDateTime;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/26 - 03 - 26 - 16:01
 * @Description: com.hym.search.utils
 * @version: 1.0
 */
public class SearchUtils {

    public   static final String INDEX = "sms_submit_log_";

    private static ThreadLocal<StandardReport> reportThreadLocal = new ThreadLocal<>();

    public  static void set(StandardReport report){
        reportThreadLocal.set(report);
    }

    public static StandardReport get(){
        return reportThreadLocal.get();
    }

    public static void remove(){
        reportThreadLocal.remove();
    }

    public static String getYear(){
        return LocalDateTime.now().getYear() + "";
    }
}
