package com.hym.search.service;

import java.io.IOException;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/21 - 03 - 21 - 16:04
 * @Description: com.hym.search.service
 * @version: 1.0
 */
public interface SearchService {

    /**
     * 向es中添加一行文档
     * @param index 索引信息
     * @param id    文档id
     * @param json  具体的文档内容
     * @throws IOException
     */
    void index(String index, String id, String json) throws IOException;

    /**
     * 查看指定索引中的文档是否存在
     * @param index
     * @param id
     * @return true表示存在；false表示不存在
     * @throws IOException
     */
    boolean exists(String index, String id) throws IOException;


    /**
     * 修改文档信息
     * @param index     指定索引
     * @param id            文档id
     * @param doc           要修改的key-value集合
     * @throws IOException
     */
    void update(String index, String id, Map<String, Object> doc) throws IOException;
}
