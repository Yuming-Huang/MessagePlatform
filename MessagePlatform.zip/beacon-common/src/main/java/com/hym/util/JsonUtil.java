package com.hym.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/21 - 03 - 21 - 16:49
 * @Description: com.hym.util
 * @version: 1.0
 */
public class JsonUtil {
    private static ObjectMapper mapper = new ObjectMapper();
    public static String objectToJson(Object obj) {
        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new RuntimeException("转换Json失败！！");
        }
    }
}
