package com.hym.util;

import com.hym.model.StandardSubmit;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 用于CMPP发送短信时，临时存储位置
 * @Auther: Yuming Huang
 * @Date: 2025/3/22 - 03 - 22 - 16:43
 * @Description: com.hym.util
 * @version: 1.0
 */
public class CMPPSubmitMapUtil {
    private static final ConcurrentHashMap<String, StandardSubmit> repoMap = new ConcurrentHashMap<>();

    public static void put(int sequence, StandardSubmit submit){
        repoMap.put(sequence +"",   submit);
    }

    public static StandardSubmit get(int sequence){
        return repoMap.get(sequence +"");
    }

    public static StandardSubmit remove(int sequence){
        return repoMap.remove(sequence +"");
    }
}
