package com.hym.util;

import com.hym.enums.CMPP2DeliverEnums;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 14:56
 * @Description: com.hym.util
 * @version: 1.0
 */
public class CMPP2DeliverUtil {
    private static Map<String, String> stat = new HashMap<>();

    static{
        CMPP2DeliverEnums[] cmpp2DeliverEnums = CMPP2DeliverEnums.values();
        for(CMPP2DeliverEnums cmpp : cmpp2DeliverEnums){
            stat.put(cmpp.getStat(),cmpp.getDescription());
        }
    }

    public static String getDescriptionByStat(String stat){
        return CMPP2DeliverUtil.stat.get(stat);
    }
}
