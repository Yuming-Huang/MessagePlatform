package com.hym.util;

import com.hym.model.StandardReport;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 14:56
 * @Description: com.hym.util
 * @version: 1.0
 */
public class CMPPDeliverMapUtil {
    private static Map<String, StandardReport> map = new HashMap<>();

    public static void put(String sequence, StandardReport submit){
        map.put(sequence +"",   submit);
    }

    public static StandardReport get(String sequence){
        return map.get(sequence +"");
    }

    public static StandardReport remove(String sequence){
        return map.remove(sequence +"");
    }
}
