package com.hym.util;

import com.hym.enums.CMPP2SubmitEnums;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 14:56
 * @Description: com.hym.util
 * @version: 1.0
 */
public class CMPP2SubimitUtil {
    private static Map<Integer, String> result = new HashMap<>();

    static{
        CMPP2SubmitEnums[] cmpp2SubmitEnums = CMPP2SubmitEnums.values();
        for(CMPP2SubmitEnums cmpp : cmpp2SubmitEnums){
            result.put(cmpp.getResult(),cmpp.getMsg());
        }
    }

    public static String getMsgByResult(Integer result){
        return CMPP2SubimitUtil.result.get(result);
    }
}
