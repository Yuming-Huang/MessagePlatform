package com.hym.util;

import com.hym.enums.MobileOperatorEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 21:56
 * @Description: com.hym.util
 * @version: 1.0
 */
public class OperatorUtil {
    private static Map<String, Integer> operatorMap = new HashMap<String, Integer>();

    static{
        MobileOperatorEnum[] operators = MobileOperatorEnum.values();
        for(MobileOperatorEnum operatorEnum : operators){
            operatorMap.put(operatorEnum.getOperatorName(),operatorEnum.getOperatorId());
        }
    }

    public static Integer getOperatorIdByOperatorName(String operatorName){
        return operatorMap.get(operatorName);
    }
}
