package com.hym.enums;

import lombok.Getter;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 21:31
 * @Description: com.hym.enums
 * @version: 1.0
 */
@Getter
public enum MobileOperatorEnum {
    CHINA_MOBILE(1,"移动"),
    CHINA_UNION(2,"联通"),
    CHINA_TELECOM(3,"电信");

    private Integer operatorId;

    private String operatorName;


    MobileOperatorEnum(Integer operatorId, String operatorName){
        this.operatorId = operatorId;
        this.operatorName = operatorName;
    }
}
