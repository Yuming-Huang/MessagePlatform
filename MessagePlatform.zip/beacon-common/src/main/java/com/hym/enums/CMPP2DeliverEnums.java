package com.hym.enums;

import lombok.Getter;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/25 - 03 - 25 - 17:28
 * @Description: com.hym.enums
 * @version: 1.0
 */
@Getter
public enum CMPP2DeliverEnums {

    /**
     * DELIVRD	    Message is delivered to destination
     * EXPIRED	    Message validity period has expired
     * DELETED     Message has been deleted
     * UNDELIV	    Message is undeliverable
     * ACCEPTD	    Message is in accepted state(i.e. has been manually read on behalf of the subscriber by customer service)
     * UNKNOWN	Message is in invalid state
     * REJECTD	    Message is in a rejected state
     */
    DELIVRD("DELIVRD","Message is delivered to destination"),
    EXPIRED("EXPIRED","Message validity period has expired"),
    DELETED("DELETED","Message has been deleted"),
    UNDELIV("UNDELIV","Message is undeliverable"),
    ACCEPTD("ACCEPTD","Message is in accepted state(i.e. has been manually read on behalf of the subscriber by customer service"),
    UNKNOWN("UNKNOWN","Message is in invalid state"),
    REJECTD("REJECTD","Message is in a rejected state")
    ;

    private String stat;

    private String description;

     CMPP2DeliverEnums(String stat, String description) {
        this.stat = stat;
        this.description = description;
    }
}
