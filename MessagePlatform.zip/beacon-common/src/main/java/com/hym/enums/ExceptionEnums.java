package com.hym.enums;

import lombok.Getter;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 15:10
 * @Description: com.hym.cache.enums
 * @version: 1.0
 */
@Getter
public enum ExceptionEnums {

    UNKNOWN_ERROR(-999,"未知错误"),
    ERROR_APIKEY(-1,"非法的apikey"),
    IP_NOT_WHITE(-2,"请求的ip不在白名单内"),
    ERROR_SIGN(-3,"无可用签名"),
    ERROR_TEMPLATE(-4,"无可用模板"),
    ERROR_MOBILE(-5,"手机号格式不正确"),
    BALANCE_NOT_ENOUGH(-6,"手客户余额不足"),
    SNOWFLAKE_OUT_OF_RANGE(-11,"雪花算法的机器id超出最大范围"),
    SNOWFLAKE_TIME_BACK(-12,"雪花算法的服务器出现时间回拨"),
    HAVE_DIRTY_WORD(-13, "当前短信内容中包含敏感信息"),
    BLACK_PLATFORM(-14, "当前手机号为平台黑名单"),
    BLACK_CLIENT(-15, "当前手机号为客户黑名单"),
    ONE_MINUTE_LIMIT(-16,"同一客户针对同一手机号的验证码内容，60s只能获取1条短信。"),
    ONE_HOUR_LIMIT(-17,"同一客户针对同一手机号的验证码内容，1小时只能获取3条短信。"),
    ONE_DAY_LIMIT(-18,"同一客户针对同一手机号的验证码内容，1天只能获取10条短信。"),
    NO_CHANNEL(-19,"没有对象的通道"),
    SEARCH_INDEX_ERROR(-20,"添加文档信息失败"),
    SEARCH_UPDATE_ERROR(-21,"修改文档信息失败")
    ;

    private Integer code;

    private String msg;

    ExceptionEnums(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
