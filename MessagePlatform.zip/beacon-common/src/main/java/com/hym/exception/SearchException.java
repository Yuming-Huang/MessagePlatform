package com.hym.exception;

import com.hym.enums.ExceptionEnums;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/21 - 03 - 21 - 16:27
 * @Description: com.hym.exception
 * @version: 1.0
 */
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SearchException extends RuntimeException {
    private Integer code;

    public SearchException(String message, Integer code) {
        super(message);
        this.code = code;
    }

    public SearchException(ExceptionEnums enums) {
        super(enums.getMsg());
        this.code = enums.getCode();
    }
}
