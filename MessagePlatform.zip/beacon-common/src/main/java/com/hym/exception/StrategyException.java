package com.hym.exception;

import com.hym.enums.ExceptionEnums;
import lombok.Data;

/**
 * 策略模块的异常对象
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 15:29
 * @Description: com.hym.exception
 * @version: 1.0
 */
@Data
public class StrategyException extends RuntimeException{
    private Integer code;

    public StrategyException(String message, Integer code) {
        super(message);
        this.code = code;
    }


    public StrategyException(ExceptionEnums enums) {
        super(enums.getMsg());
        this.code = enums.getCode();
    }
}
