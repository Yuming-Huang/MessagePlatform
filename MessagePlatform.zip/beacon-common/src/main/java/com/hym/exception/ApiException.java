package com.hym.exception;


import com.hym.enums.ExceptionEnums;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 15:12
 * @Description: com.hym.cache.exception
 * @version: 1.0
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ApiException extends RuntimeException {

    private Integer code;

    public ApiException(String message, Integer code) {
        super(message);
        this.code = code;
    }


    public ApiException(ExceptionEnums enums) {
        super(enums.getMsg());
        this.code = enums.getCode();
    }
}
