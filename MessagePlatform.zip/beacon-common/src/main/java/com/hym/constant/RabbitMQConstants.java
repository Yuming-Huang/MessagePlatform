package com.hym.constant;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 15:37
 * @Description: com.hym.constant
 * @version: 1.0
 */
public interface RabbitMQConstants {
    /**
     * 接口模块发送消息到策略模块的队列名称
     */
    String SMS_PRE_SEND = "sms_pre_send_topic";

    /**
     * 接口模块发送手机号归属地&运营商到后台管理模块的队列名称
     */
    String MOBILE_AREA_OPERATOR = "mobile_area_operator";

    /**
     * 写日志到Elasticsearch的队列
     */
    String SMS_WRITE_LOG = "sms_write_log_topic";

    /**
     * 写日志到推送模块的队列
     */
    String SMS_PUSH_REPORT = "sms_push_report_topic";

    /**
     * 策略模块推送消息到短信网关模块的队列前缀名称
     */
    String SMS_GATEWAY = "sms_gateway";

    /**
     *  推送模块监听自己发出的延迟消息
     */
    String DELAYED_QUEUE= "push_delayed_queue";

    //  声明死信队列，需要准备交换机和队列，死信交换机和死信队列
    public final static String SMS_GATEWAY_NORMAL_EXCHANGE = "sms_gateway_normal_exchange";
    public final static String SMS_GATEWAY_NORMAL_QUEUE = "sms_gateway_normal_queue";
    public final static String SMS_GATEWAY_DEAD_EXCHANGE = "sms_gateway_dead_exchange";
    public final static String SMS_GATEWAY_DEAD_QUEUE = "sms_gateway_dead_queue";
}
