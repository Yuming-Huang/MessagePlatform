package com.hym.constant;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 17:48
 * @Description: com.hym.constant
 * @version: 1.0
 */
public interface ApiConstant {
    /**
     * 签名的前缀
     */
    String SIGN_PREFIX = "【";
    /**
     * 签名的后缀
     */
    String SIGN_SUFFIX = "】";

    /**
     * 单条短信费用，默认是50（厘）
     */
    Long SINGLE_FEE = 50L;
}
