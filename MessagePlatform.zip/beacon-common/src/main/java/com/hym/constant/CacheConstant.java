package com.hym.constant;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/17 - 03 - 17 - 14:51
 * @Description: 缓存模块中的各种前缀
 * @version: 1.0
 */
public interface CacheConstant {

    /**
     * 客户信息
     */
    String CLIENT_BUSINESS = "client_business:";

    /**
     * 客户签名
     */
    String CLIENT_SIGN = "client_sign:";

    /**
     * 客户签名的模板
     */
    String CLIENT_TEMPLATE = "client_template:";

    /**
     * 客户的余额
     */
    String CLIENT_BALANCE = "client_balance:";

    /**
     * 号段
     */
    String PHASE = "phase:";

    /**
     * 敏感词
     */
    String DIRTY_WORD = "dirty_word:";

    /**
     * 黑名单
     */
    String BLACK = "black:";

    /**
     * 黑名单检索中的分隔符
     */
    String SEPARATE = ":";

    /**
     *  携号转网
     */
    String TRANSFER = "transfer:";

    /**
     *  一分钟限流
     */
    String LIMIT_MINUTES = "limit:minutes:";

    /**
     *  一小时限流
     */
    String LIMIT_HOURS = "limit:hours:";

    /**
     *  一天限流
     */
    String LIMIT_DAYS = "limit:day:";


    /**
     *  路由通道
     */
    String CHANNEL = "channel:";

    /**
     *  路由通道
     */
    String CLIENT_CHANNEL = "client_channel:";
}
