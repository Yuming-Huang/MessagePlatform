package com.hym.constant;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/19 - 03 - 19 - 15:59
 * @Description: com.hym.constant
 * @version: 1.0
 */
public interface StrategyConstant {

    /**
     * 短信发送成功
     */
    int REPORT_SUCCESS = 1;

    /**
     * 短信发送失败
     */
    int REPORT_FAILURE = 2;

    String IS_CALLBACK = "isCallback";

    String CALLBACK_URL = "callbackUrl";

    Integer CALLBACK_CODE = 1;

    /**
     * 验证码类型短信
     */
    int CODE_TYPE   = 0;

    /**
     * 通知类型短信
     */
    int NOTIFY_TYPE   = 0;

    /**
     * 营销类型短信
     */
    int MARKETING_TYPE   = 0;




}
