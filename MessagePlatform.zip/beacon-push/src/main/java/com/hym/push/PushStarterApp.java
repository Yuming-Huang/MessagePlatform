package com.hym.push;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Auther: Yuming Huang
 * @Date: 2025/3/18 - 03 - 18 - 16:52
 * @Description: com.hym.strategy
 * @version: 1.0
 */
@SpringBootApplication
@EnableDiscoveryClient
public class PushStarterApp {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        SpringApplication.run(PushStarterApp.class,args);
    }
}
